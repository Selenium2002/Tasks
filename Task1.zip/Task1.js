function firstTask(channels, categories) {

    return channels + " : " + categories; 

}

document.getElementById("task").innerHTML = firstTask("paramount", "comedy");



function taskZero(chanels, catigories) {

    return chanels + " : " + catigories; 

}

document.getElementById("task0").innerHTML = taskZero("itv4", "sport");



function taskOne(channils, categuries) {

    return channils + " : " + categuries; 

}

document.getElementById("task1").innerHTML = taskOne("spirit", "religion");







