function firstTask(channels, categories) {

    var channels = ["paramount", "itv4", "spirit"],

        categories = ["comedy", "sport", "religion"];

        for (let i = 0; i < channels.length, i < categories.length; i++) {
            alert (channels[i] + " : " + categories[i]);

        }
  
}

document.getElementById("task").innerHTML = firstTask();






 







