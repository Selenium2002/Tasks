function secondTask() {

    var values = ["5", "1", "-1", "3", "10"];

    return values;

}

document.getElementById("task").innerHTML = secondTask();